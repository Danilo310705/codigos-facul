
class loopWhile {

    public static void main(String[] args) {

        int cont = 67;

        while (cont < 73) {
            System.out.println("Contador " + cont);
            cont++;
        }
    }
}
