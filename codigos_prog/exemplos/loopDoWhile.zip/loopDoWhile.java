class loopDoWhile {
    
    public static void main(String[] args) {
        
        int cont = 73;

        do { 
            System.out.println("contador " + cont);
            cont++;
        } while (cont < 73);
    }
}
