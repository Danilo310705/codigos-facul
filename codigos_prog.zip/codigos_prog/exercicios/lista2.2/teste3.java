import java.util.Scanner;
public class teste3 {
    public static void main(String [] args){
        int soma = 0;
        int numDigitado = 1;
        try(Scanner scan = new Scanner(System.in)){

            while (numDigitado != 0){
                System.out.print("Digite um número (digite 0 para sair): ");
                    numDigitado = scan.nextInt();

                if(numDigitado >= 0 && numDigitado <= 100){
                    
                    
                    if (numDigitado == 0) {
                        System.out.println("");
                    }else if(epar(numDigitado)){
                        soma += numDigitado;   
                        System.out.println("Número somado");
                    }else{
                        System.out.println("Número não somado");
                    }
                }else{
                    System.out.println("Número inválido");
                }

            }

            System.out.print("Resultado: " + soma);
        }
    }

    public static boolean epar(int n){
        if(n%2 == 0){
            return true;
        }else{
            return false;
        }
    }

}