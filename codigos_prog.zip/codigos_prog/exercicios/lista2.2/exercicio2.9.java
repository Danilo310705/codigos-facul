import java.util.Scanner;

class exercicio05 {
    
    public static void main(String[] args) {
        
        int anoNascimento, anoAtual, idade;

        try(Scanner s = new Scanner(System.in)){

        
    }
}
