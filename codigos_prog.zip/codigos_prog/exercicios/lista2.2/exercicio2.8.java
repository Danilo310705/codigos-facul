import java.util.Scanner;

class exercicio28 {
    
    public static void main(String[] args) {
        
        int idade;
        String clasificacao;

        try(Scanner s = new Scanner(System.in)){
            
            
        }
    }

}

