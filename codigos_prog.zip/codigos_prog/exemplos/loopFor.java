class loopFor {

    public static void main(String[] args) {
        
        for (int i=67; i < 73; i++ ){
            System.out.println("contador " + i);
        }
    }
}
