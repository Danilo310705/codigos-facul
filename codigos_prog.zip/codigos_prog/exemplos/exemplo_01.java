class exemplo_01{

    public static void main(String[] args){
        System.out.println("Hello Word!");       
        int idade = 20;
        String nome = "Danilo Sanches";
        boolean status_aluno = true;
        char periodo = '2';
        System.out.println("Hello Word! eu sou " + nome + " e estou no " + periodo + " periodo \n minha matricula esta " + status_aluno + " e tenho " + idade + " anos.");
    } 
    
}